library(ggplot2)
library(factoextra)
library(purrr)
library(cluster)
library(purrr)
library(caret)
library(ClusterR)
library(gtools)
library("dplyr")
library(data.table)
library(readxl)

##########################################################################
###############Unsupervised Learning: K-means Cluster#####################
##########################################################################
df1<- read_excel("Documents/Machine_Learning_R/R_Machine_Learning-master/Unsup_data/aniso.xlsx")
df2<- read_excel("Documents/Machine_Learning_R/R_Machine_Learning-master/Unsup_data/blobs.xlsx")
df3<- read_excel("Documents/Machine_Learning_R/R_Machine_Learning-master/Unsup_data/no_structure.xlsx")
df4<- read_excel("Documents/Machine_Learning_R/R_Machine_Learning-master/Unsup_data/noisy_circles.xlsx")
df5<- read_excel("Documents/Machine_Learning_R/R_Machine_Learning-master/Unsup_data/noisy_moons.xlsx")
df6<- read_excel("Documents/Machine_Learning_R/R_Machine_Learning-master/Unsup_data/varied.xlsx")

#Inspect each dataset visually:
plot(df1) # looks like there are 3 clusters
plot(df2) # looks like there are 3 clusters
plot(df3) # visually not clear how many clusters
plot(df4) # 2 clusters
plot(df5) # 2 clusters
plot(df6) # visually, it appears there are 3 clusters

#K-means clusterings for each dataset
kdf1_3cl<-kmeans(df1, centers=3)
kdf2_3cl<-kmeans(df2, centers=3)
kdf3_3cl<-kmeans(df3, centers=3) # I will try 3
kdf4_2cl<-kmeans(df4, centers=2)
kdf5_2cl<-kmeans(df5, centers=2)
kdf6_3cl<-kmeans(df6, centers=3)

#Inspect centers:
kdf1_3cl$centers
kdf2_3cl$centers
kdf3_3cl$centers
kdf4_2cl$centers
kdf5_2cl$centers
kdf6_3cl$centers

#Inspect clusters:
kdf1_3cl$cluster
kdf2_3cl$cluster
kdf3_3cl$cluster
kdf4_2cl$cluster
kdf5_2cl$cluster
kdf6_3cl$cluster

#Plot each one
# Plot#1
plot(df1[kdf1_3cl$cluster==1, ], col='red', xlim=c(min(df1[,1]), max(df1[,1])), ylim=c(min(df1[,2]), max(df1[,2])))
points(df1[kdf1_3cl$cluster==2, ], col='blue')
points(df1[kdf1_3cl$cluster==3, ], col='seagreen')

# Plot#2
plot(df2[kdf2_3cl$cluster==1, ], col='red', xlim=c(min(df2[,1]), max(df2[,1])), ylim=c(min(df2[,2]), max(df2[,2])))
points(df2[kdf2_3cl$cluster==2, ], col='blue')
points(df2[kdf2_3cl$cluster==3, ], col='seagreen')

# Plot#3
plot(df3[kdf3_3cl$cluster==1, ], col='red', xlim=c(min(df3[,1]), max(df3[,1])), ylim=c(min(df3[,2]), max(df3[,2])))
points(df3[kdf3_3cl$cluster==2, ], col='blue')
points(df3[kdf3_3cl$cluster==3, ], col='seagreen')

# Plot#4
plot(df4[kdf4_2cl$cluster==1, ], col='red', xlim=c(min(df4[,1]), max(df4[,1])), ylim=c(min(df4[,2]), max(df4[,2])))
points(df4[kdf4_2cl$cluster==2, ], col='blue')

# Plot#5
plot(df5[kdf5_2cl$cluster==1, ], col='red', xlim=c(min(df5[,1]), max(df5[,1])), ylim=c(min(df5[,2]), max(df5[,2])))
points(df5[kdf5_2cl$cluster==2, ], col='blue')

# Plot#6
plot(df6[kdf6_3cl$cluster==1, ], col='red', xlim=c(min(df6[,1]), max(df6[,1])), ylim=c(min(df6[,2]), max(df6[,2])))
points(df6[kdf6_3cl$cluster==2, ], col='blue')
points(df6[kdf6_3cl$cluster==3, ], col='seagreen')


##########################################################################
#################Supervised Learning: K-means Cluster#####################
##########################################################################
library(e1071)
df<- read_excel("Documents/Machine_Learning_R/final_dataset_gb.xlsx")
# Variables of interes: X=rank, avg_rating,num_voters and y=rating
y<-df$rating #games with ratings below 6.5 are "bad" and with ratings equal to or greater than 6.5 are "good"
y[y<6.5]<-0
y[y>=6.5]<-1
df$y<-y
df$y<-factor(df$y)
levels(df$y) <- c(FALSE,TRUE) #TRUE=1 i.e. good games, FALSE=0 i.e. bad games
df$y <- as.logical(df$y)
set.seed(12)
indT<-createDataPartition(y=df$y,p=0.5,list=FALSE)
training<-df[indT,]
testing <-df[-indT,]

#Perform exercise on a full sample first:
Fit_SVM_ln <- svm(y~rank+avg_rating+num_voters,
                  data=df,kernel="sigmoid", type="C") #sigmoid kernel
summary(Fit_SVM_ln) 

Fit_SVM_rbg <- svm(y~rank+avg_rating+num_voters,
                   data=df,kernel="radial",gamma=0.1, type="C") #radial kernel
summary(Fit_SVM_rbg)

#Confusion matrix and missclassification error rate.
pred_rbg <- predict(Fit_SVM_ln,df)
tab<-table(Predicted=pred_rbg, Actual=df$y)
tab #based on this table the model incorrectly predicted 253 games as "good" while they were bad and 
# 249 games were predicted as "bad" but were good.  6800 bad games were correctly classified as bad, and 676 good 
# games were correctly classified as good.

#Misclassification rate is:
mrate<-1-sum(diag(tab))/sum(tab)
mrate  #missclassification rate is approximately 6%... not bad!

confusionMatrix(df$y,pred_rbg)

#use split data
Fit_SVM_ln <- svm(y~rank+avg_rating+num_voters,
                  data=training,kernel="sigmoid", type="C") #sigmoid kernel
summary(Fit_SVM_ln) 

Fit_SVM_rbg <- svm(y~rank+avg_rating+num_voters,
                   data=training,kernel="radial",gamma=0.1, type="C") #radial kernel
summary(Fit_SVM_rbg)

pred_rbg <- predict(Fit_SVM_ln,testing)
confusionMatrix(as.factor(testing$y),pred_rbg)
